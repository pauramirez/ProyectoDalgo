package problemaB;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ProblemaB
{
	public static int[] problemaBCredibilidad(int[] datos)
	{
		int rMax = 0;
		int r = 0;
		int p = 0;
		int pMax = 0;
		int q = -1;
		int[] resp = new int[3];
		
		for(int i = 0; i < datos.length; i++)
		{
			if(datos[i] > 0)
			{
				r = r + 1;

			}
			else if(datos[i] < 0)
			{
				r = r -1;
			}
			if(r < 0)
			{
				r = 0;
				p = i + 1;
			}
			if(rMax < r)
			{
				pMax = p;
				rMax = r;
				q = i;
			}
		}

		resp[0] = rMax;
		resp[1] = pMax;
		resp[2] = q + 1;
		return resp;
		
	}

	public static void main(String[] args) 
	{
		System.out.println("Ingrese la cantidad de datos que quiere procesar");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String entrada;
		String entradaProcesada;
		try {
			entrada = br.readLine();
			int dimension = Integer.parseInt(entrada);
			System.out.println("Ingresar los datos. Separar datos por espacios.");
			entradaProcesada = br.readLine();
			String[] arreglo = entradaProcesada.split(" ");
			int[] data = new int[dimension];
			for(int i = 0; i < dimension; i++)
			{
				data[i] = Integer.parseInt(arreglo[i]);
			}
			int[] salida = problemaBCredibilidad(data);
		     	System.out.print(salida[0]);
				System.out.print(" ");
				System.out.print(salida[1]);
				System.out.print(" ");
				System.out.print(salida[2]);
		    } 
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

}
