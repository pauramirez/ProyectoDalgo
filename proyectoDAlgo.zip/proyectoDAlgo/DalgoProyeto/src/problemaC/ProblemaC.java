package problemaC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ProblemaC {
	
	public static void main(String[] args) throws IOException
	{
		System.out.println("Ingrese las cadenas z separando cada dijito por espacio ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String ln = br.readLine();
		while(ln != null){
			
		}
	}

}
