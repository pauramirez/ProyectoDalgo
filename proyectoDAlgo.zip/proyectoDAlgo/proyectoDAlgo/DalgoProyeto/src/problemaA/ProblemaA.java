package problemaA;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ProblemaA 
{
	public static int[] problemaAProductoPunto(int[] datos)
	{
		int[] data = new int[datos.length];
		for(int i = 0; i < datos.length-1; i++)
		{
			for(int j = i+1; j< datos.length; j++)
			{
				int[] resp = extendedEuclideanAlgorythm(datos[i],datos[j]);
				if(resp[0] == 1)
				{
					data[i] = resp[1];
					data[j] = resp[2];
					return data;
				}
			}
		}
		return null;
	}

	
	public static int[] extendedEuclideanAlgorythm(int a, int b)
	/*  Retorna d y numeros j and k tal que 
               d = j*a + k*b
        donde d es el mcd de a y b.
	 */
	{ 
		int[] ans = new int[3];
		int q;

		if (b == 0)  {  /*  Si b = 0, terminamos...  */
			ans[0] = a;
			ans[1] = 1;
			ans[2] = 0;
		}
		else
		{     /*  De lo contrario, recursivo  */ 
			q = a/b;
			ans = extendedEuclideanAlgorythm (b, a % b);
			int temp = ans[1] - ans[2]*q;
			ans[1] = ans[2];
			ans[2] = temp;
		}

		return ans;
	}

	public static void main(String[] args) 
	{
		System.out.println("Ingrese la cantidad de datos que quiere procesar, luego los datos. Separar todo por espacios.");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String entradaProcesada;
		try {
			entradaProcesada = br.readLine();
			String[] datos = entradaProcesada.split(" ");
			int[] data = new int[datos.length - 1];
			for(int i = 1; i < datos.length; i++)
			{
				data[i-1] = Integer.parseInt(datos[i]);
			}
			int[] salida = problemaAProductoPunto(data);
			if(salida != null)
			{
				for(int j = 0; j < data.length;j++)
				{
					System.out.print(salida[j]);
					if(j< data.length-1)
					{
						System.out.print(" ");
					}
				}
			}
			else
			{
				System.out.println("*");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
